#include <stdio.h>
#include <sys/ipc.h>//add by lcj
#include <sys/shm.h>//add by lcj
#include <sys/types.h>//add by lcj
#include <sys/sem.h>//add by lcj
void* linktoshared(key_t key,int size);
void delink(const void* linkto);
void deshared(key_t key);
void getsignal(key_t key);
void setsignal(key_t key,int value);
void P(key_t key);
void V(key_t key);
void designal(key_t key);
void Messagepss(int srX,int srY,int dtX,int dtY,int packagesize,char* s);
long long unsigned Getgpgpusimcycle();
void splitMessage(unsigned long long *,int,int,int,int,int);
void Synchronization();
union semun 
{
    int val;
    struct semid_ds *buf;
    unsigned short *arry;
};
void* linktoshared(key_t key,int size)//add by lcj
{
   int shmid;
   if ( (shmid = shmget(key, size, 0640|IPC_CREAT)) == -1)
   { printf("link to sharedmemory(%d) failed\n",key);}
   return shmat(shmid,0,0);
}
void delink(const void* linkto)//add by lcj
{
   if(shmdt(linkto)==-1)
   printf("destory link failed\n");
}
void deshared(key_t key)//add by lcj
{
  int shmid;
  if ( (shmid = shmget(key, 0, 0640|IPC_CREAT)) == -1)
  {printf("shared memory(%d) not exsit\n",key);return;}
  if (shmctl(shmid, IPC_RMID, 0) == -1)
  { printf("destroy sharedmemory(%d) failed\n",key); }
}
void setsignal(key_t key,int value){//add by lcj
  int sem_id;
  if ( (sem_id=semget(key,1,0640|IPC_CREAT)) == -1){
    printf("signal(key:%d) creation failed\n",key);
  }
    union semun sem_union;
    sem_union.val = value;
    if (semctl(sem_id,0,SETVAL,sem_union) <  0) {
      printf("signal(key:%d) initialization failed\n",key); 
    }else{
      printf("signal(key:%d) initialization successed sem_id:%d\n",key,sem_id);
    }
}
void P(key_t key)//add by lcj
{
  int sem_id;
  struct sembuf sem_b;
  if((sem_id=semget(key,1,0640|IPC_CREAT)) == -1){
    printf("signal(%d) error\n",key);
  }
  sem_b.sem_num = 0;
  sem_b.sem_op = -1;
  sem_b.sem_flg = 0;
  if (semop(sem_id, &sem_b, 1) == -1)
  {
    printf("P(%d)failed\n",key);
  }
}
void V(key_t key)//add by lcj
{
  int sem_id;
  struct sembuf sem_b;
  if((sem_id=semget(key,1,0640|IPC_CREAT)) == -1)
  printf("signal(%d) error \n",key);
  sem_b.sem_num = 0;
  sem_b.sem_op = 1;
  sem_b.sem_flg = 0;
  if (semop(sem_id, &sem_b, 1) == -1)
  {
    printf("V(%d)failed\n",key);
  }
}
void designal(key_t key)//add by lcj
{
  int  sem_id;
  if ( (sem_id=semget(key,1,0640)) == -1)
  {printf("signal(%d not exsit\n",key);return;}
  if (semctl(sem_id,0,IPC_RMID) == -1)
   printf("destory signal (%d) faild\n",key);
}


void splitMessage(unsigned long long *cycle,int size,int srx,int sry,int dsx,int dsy){//add by lcj
    FILE* pf;
    pf = fopen("trace/bench", "a+");
    char s[100];
    int curcycle=*cycle;
    while(size>0){
	    curcycle++;
        if(size>=1000){
                sprintf(s,"%d %d %d %d %d %d\n%d %d %d %d %d %d\n",curcycle,srx,sry,dsx,dsy,1000,curcycle+1,srx,sry,dsx,dsy,1000);
        }else{
                sprintf(s,"%d %d %d %d %d %d\n%d %d %d %d %d %d\n",curcycle,srx,sry,dsx,dsy,size,curcycle+1,srx,sry,dsx,dsy,size);
        }
        fputs(s, pf);
        s[0]='\0';
        size-=1000;
    }
    *cycle=curcycle;
    fclose(pf);
}
long long unsigned Getgpgpusimcycle(){
    return 1;
}
void Synchronization(){

}
