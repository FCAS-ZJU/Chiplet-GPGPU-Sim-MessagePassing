rm ./trace/bench
touch ./trace/bench
cat ./trace/bench* >> ./trace/bench
sort -n -k 1 ./trace/bench -o ./trace/bench
../popnet/popnet -A 2 -c 2 -V 1 -B 12 -O 12 -F 4 -L 1000 -T 5000000 -r 1 -I ./trace/bench -R 0

