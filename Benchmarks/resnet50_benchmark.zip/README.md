
#在darknet官网下载resnet50的配置文件，https://pjreddie.com/media/files/resnet50.weights
#直接make即可，文件下有两个可执行文件，resnet50_chiplet1 和 resnet50_chiplet2，先执行resnet50_chiplet1（初始化）并输入编号1，在执行resnet50_chiplet2并输入编号2，运行结束将询问是否开始运行popnet，Y即可。

