rm _*  *.sm_* trace/* buffer*
